package ainaa.acup.javaLogic;

public class CheckMyPcDTO {

	private String pcName;
	private String ip;
	public String getPcName() {
		return pcName;
	}
	public void setPcName(String pcName) {
		this.pcName = pcName;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
}

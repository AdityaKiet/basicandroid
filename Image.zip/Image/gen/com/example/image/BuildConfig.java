/** Automatically generated file. DO NOT MODIFY */
package com.example.image;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
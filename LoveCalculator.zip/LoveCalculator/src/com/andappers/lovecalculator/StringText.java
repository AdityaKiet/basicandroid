package com.andappers.lovecalculator;

public class StringText {
	static String[] title = { "Goergous", "Bekar" };
	static String[] text = { "Lovers", "Not Lovers" };
	static int[] percentage = { 2, 4 };
}

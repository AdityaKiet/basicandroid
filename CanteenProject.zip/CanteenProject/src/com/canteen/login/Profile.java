package com.canteen.login;

import com.andappers.canteenproject.R;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Profile extends Activity {
	Bundle basket;
	String name, account_number, roll_no, balance, last_recharge;
	TextView tv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile);
		tv = (TextView) findViewById(R.id.test);
		basket = getIntent().getExtras();
		name = basket.getString("name");
		account_number = basket.getString("account_number");
		roll_no = basket.getString("roll_no");
		last_recharge = basket.getString("last_recharge");
		tv.setText(account_number + name + roll_no + last_recharge);
	}

}

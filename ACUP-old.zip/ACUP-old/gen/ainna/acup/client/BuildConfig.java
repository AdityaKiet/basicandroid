/** Automatically generated file. DO NOT MODIFY */
package ainna.acup.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package ainaa.acup.javaLogic;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

import ainaa.acup.config.UbuntuReader;

public class Data {

	public static Socket socket;
	public static DataInputStream din;
	public static DataOutputStream dout;
	public static UbuntuReader reader;
}

/** Automatically generated file. DO NOT MODIFY */
package com.andappers.canteenproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
/** Automatically generated file. DO NOT MODIFY */
package com.kiet.android_login_registration;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}